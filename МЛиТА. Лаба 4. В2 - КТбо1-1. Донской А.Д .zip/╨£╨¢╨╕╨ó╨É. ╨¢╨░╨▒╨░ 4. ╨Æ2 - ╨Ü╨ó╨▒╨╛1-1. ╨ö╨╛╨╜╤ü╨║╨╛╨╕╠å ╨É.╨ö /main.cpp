//
// Created by Антон Донской on 14.05.2018.
//

/*
	Данная программа реализует и 3, и 2 вариант. Стандартно программа решает вариант 3. Для решения задачи варинта 2 нужно создать config.txt, в котором прописать номер варианта и максимальное колличество повторений(нужно только для 2 варианта)
*/
#include "DataSet.h"

int main() {
    DataSet a;
    make_bin_file("input.txt", "input.bin");
    a.input("input.bin");
    a.select();
    a.output("output.txt");

    return 0;
}